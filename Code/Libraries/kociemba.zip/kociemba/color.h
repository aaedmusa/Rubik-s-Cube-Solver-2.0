#pragma once

#include "arduino_undefine.h"


namespace kociemba
{

	// Names the colors of the cube facelets
	typedef enum { U, R, F, D, L, B } color_t;

#define COLOR_COUNT 6

}
/* end of file */ 

